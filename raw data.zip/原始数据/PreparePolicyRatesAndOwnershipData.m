%% PreparePolicyRatesAndOwnershipData.m
% Purpose:
%   1) Convert R007 and DR007 daily observations to quarterly means.
%   2) Convert the PBOC 7-day reverse-repo operation rate to a step-function
%      policy-rate series, then calculate quarterly means.
%   3) Forward-fill the monthly 1-year MLF rate between adjustments and
%      calculate quarterly means.
%   4) Merge the policy/funding-rate series with ownership-specific fixed
%      asset investment growth.
%   5) Export a clean quarterly dataset, variable definitions, coverage
%      diagnostics, a MAT file, and a verification figure.
%
% IMPORTANT MEASUREMENT NOTES:
%   - R007 is the weighted 7-day interbank pledged-repo rate for the whole
%     interbank market. It is a market funding rate, NOT a policy rate.
%   - DR007 is the weighted 7-day pledged-repo rate among depository
%     institutions. Official data begin on 15-Dec-2014; use complete
%     quarters from 2015Q1.
%   - The 7-day reverse-repo rate is an operation/policy rate. It is treated
%     as a step function: the last announced rate remains effective until
%     the next observed change/operation. The strict sample starts 2016Q1.
%   - The 1-year MLF rate is monthly. Missing months are filled using the
%     previous effective rate. The strict sample starts 2016Q2.
%   - The three ownership-investment variables in the supplied workbook are
%     quarter-end year-to-date cumulative YoY growth rates. They are NOT
%     stand-alone single-quarter growth rates.
%
% Required files (place in the same folder as this script):
%   中国_银行间质押式回购加权利率_7天.xlsx
%   中国_存款类机构质押式回购加权利率_7天.xlsx
%   中国_逆回购利率_7天.xlsx
%   中国_中期借贷便利(MLF)利率_1年.xlsx
%   69e5332f-2fa6-470f-8cd3-9bb9c50b9ff2.xlsx
%
% MATLAB requirement:
%   Local functions in scripts require MATLAB R2016b or later.

clear; clc; close all;

%% 1. Configuration
baseDir = fileparts(mfilename('fullpath'));
if isempty(baseDir)
    baseDir = pwd;
end

fileR007  = fullfile(baseDir, '中国_银行间质押式回购加权利率_7天.xlsx');
fileDR007 = fullfile(baseDir, '中国_存款类机构质押式回购加权利率_7天.xlsx');
fileRepo7 = fullfile(baseDir, '中国_逆回购利率_7天.xlsx');
fileMLF   = fullfile(baseDir, '中国_中期借贷便利(MLF)利率_1年.xlsx');
fileInv   = fullfile(baseDir, 'FAI_Quarterly_Data.xlsx');

% Current paper sample
sampleStart = datetime(2005,1,1);
sampleEnd   = datetime(2023,9,30);

% Strict starting dates for shorter official series
dr007Start  = datetime(2015,1,1);   % first complete quarter
repo7Start  = datetime(2016,1,1);   % stable modern operating framework
mlfStart    = datetime(2016,4,1);   % first complete usable quarter: 2016Q2

% Minimum observations required in a quarter
minTradingDays = 20;    % R007 and DR007
minCalendarDays = 60;   % reverse-repo step series
minMonths       = 3;    % MLF quarterly mean

outputXlsx = fullfile(baseDir, 'Processed_PolicyRates_Ownership_Quarterly.xlsx');
outputMat  = fullfile(baseDir, 'Processed_PolicyRates_Ownership_Quarterly.mat');
outputFig  = fullfile(baseDir, 'Processed_PolicyRates_Ownership_Verification.png');

requiredFiles = {fileR007,fileDR007,fileRepo7,fileMLF,fileInv};
for i = 1:numel(requiredFiles)
    assert(isfile(requiredFiles{i}), 'Missing input file: %s', requiredFiles{i});
end

%% 2. Read raw vendor files
% The four rate workbooks contain 9 metadata rows; observations start at row 10.
[dateR007,  valR007,  metaR007]  = readVendorTwoColumnFile(fileR007);
[dateDR007, valDR007, metaDR007] = readVendorTwoColumnFile(fileDR007);
[dateRepo7, valRepo7, metaRepo7] = readVendorTwoColumnFile(fileRepo7);
[dateMLF,   valMLF,   metaMLF]   = readVendorTwoColumnFile(fileMLF);

validateRateSeries(dateR007,  valR007,  'R007');
validateRateSeries(dateDR007, valDR007, 'DR007');
validateRateSeries(dateRepo7, valRepo7, '7-day reverse repo');
validateRateSeries(dateMLF,   valMLF,   '1-year MLF');

%% 3. Daily market/core funding rates -> quarterly means
% No forward filling: average only actual trading-day observations.
R007_Q = observedRateToQuarterly( ...
    dateR007, valR007, sampleStart, sampleEnd, ...
    'R007_QMean', 'R007_ObsN', minTradingDays);

DR007_Q = observedRateToQuarterly( ...
    dateDR007, valDR007, dr007Start, sampleEnd, ...
    'DR007_QMean', 'DR007_ObsN', minTradingDays);

%% 4. Reverse-repo operation rate -> daily step function -> quarterly mean
% Use the last available operation rate as the effective rate until the next
% observation. The strict series begins in 2016Q1; do not backfill 2005-2015.
[Repo7_Q, Repo7_Daily] = eventRateToQuarterly( ...
    dateRepo7, valRepo7, repo7Start, sampleEnd, ...
    'Repo7D_QMean', 'Repo7D_CalendarDays', 'Repo7D_EventN', ...
    minCalendarDays, 'daily');

%% 5. Monthly 1-year MLF rate -> monthly step function -> quarterly mean
% Missing months between observed announcements are filled with the previous
% effective rate. The strict sample begins in 2016Q2.
[MLF_Q, MLF_Monthly] = eventRateToQuarterly( ...
    dateMLF, valMLF, mlfStart, sampleEnd, ...
    'MLF1Y_QMean', 'MLF1Y_Months', 'MLF1Y_ReportedMonths', ...
    minMonths, 'monthly');

%% 6. Read ownership-specific investment data
Investment_Q = readOwnershipInvestment(fileInv, sampleStart, sampleEnd);

%% 7. Create the master quarterly calendar and merge all series
qStart = dateshift(sampleStart, 'start', 'quarter');
qEnd   = dateshift(sampleEnd,   'start', 'quarter');
quarterStarts = (qStart:calmonths(3):qEnd)';
quarterDates  = dateshift(quarterStarts, 'end', 'quarter');

Master = table( ...
    quarterDates, ...
    year(quarterDates), ...
    ceil(month(quarterDates)/3), ...
    'VariableNames', {'Date','Year','Quarter'});

Master = leftJoinByDate(Master, R007_Q);
Master = leftJoinByDate(Master, DR007_Q);
Master = leftJoinByDate(Master, Repo7_Q);
Master = leftJoinByDate(Master, MLF_Q);
Master = leftJoinByDate(Master, Investment_Q);
Master = sortrows(Master, 'Date');

%% 8. Construct useful spreads for Proposition 2
% These are diagnostic wedges, not interchangeable policy rates.
Master.R007_DR007_Spread = Master.R007_QMean - Master.DR007_QMean;
Master.R007_Repo7D_Spread = Master.R007_QMean - Master.Repo7D_QMean;
Master.DR007_Repo7D_Spread = Master.DR007_QMean - Master.Repo7D_QMean;

% Suggested empirical use:
%   Full sample funding condition:       R007_QMean
%   Core-bank funding robustness:        DR007_QMean
%   Strict short-term policy rate:       Repo7D_QMean
%   Medium-term policy-rate robustness:  MLF1Y_QMean

%% 9. Coverage and missing-value diagnostics
keyVars = { ...
    'R007_QMean', ...
    'DR007_QMean', ...
    'Repo7D_QMean', ...
    'MLF1Y_QMean', ...
    'FAI_SOE_CumYoY', ...
    'FAI_POE_CumYoY', ...
    'FAI_FIE_CumYoY'};

Coverage = buildCoverageTable(Master, keyVars);

fprintf('\n============================================================\n');
fprintf('Quarterly dataset prepared: %dQ%d to %dQ%d\n', ...
    year(Master.Date(1)), ceil(month(Master.Date(1))/3), ...
    year(Master.Date(end)), ceil(month(Master.Date(end))/3));
fprintf('Number of quarters: %d\n', height(Master));
fprintf('============================================================\n');
disp(Coverage);

fprintf('\nImportant investment-data warning:\n');
fprintf(['FAI_SOE_CumYoY, FAI_POE_CumYoY and FAI_FIE_CumYoY are\n' ...
         'quarter-end year-to-date cumulative YoY rates, not independent\n' ...
         'single-quarter investment-growth rates.\n\n']);

%% 10. Variable-definition sheet
Definitions = table( ...
    { ...
    'R007_QMean'; ...
    'DR007_QMean'; ...
    'Repo7D_QMean'; ...
    'MLF1Y_QMean'; ...
    'R007_DR007_Spread'; ...
    'R007_Repo7D_Spread'; ...
    'DR007_Repo7D_Spread'; ...
    'FAI_SOE_CumYoY'; ...
    'FAI_POE_CumYoY'; ...
    'FAI_FIE_CumYoY'}, ...
    { ...
    'Quarterly arithmetic mean of actual daily R007 observations'; ...
    'Quarterly arithmetic mean of actual daily DR007 observations'; ...
    'Quarterly mean of the calendar-day step function of the 7-day PBOC reverse-repo operation rate'; ...
    'Quarterly mean of the monthly step function of the 1-year MLF rate'; ...
    'R007 minus DR007; broad-market nonbank/intermediation premium'; ...
    'R007 minus the 7-day reverse-repo operation rate'; ...
    'DR007 minus the 7-day reverse-repo operation rate'; ...
    'SOE fixed-asset investment, quarter-end year-to-date cumulative YoY growth'; ...
    'Private fixed-asset investment, quarter-end year-to-date cumulative YoY growth'; ...
    'Foreign-invested fixed-asset investment, quarter-end year-to-date cumulative YoY growth'}, ...
    { ...
    'Market funding rate; full-sample funding-condition proxy; not a policy rate'; ...
    'Core depository-institution funding rate; available from 2015Q1'; ...
    'Strict short-term policy-rate measure; strict sample from 2016Q1'; ...
    'Medium-term policy-rate measure; strict sample from 2016Q2'; ...
    'Funding-market segmentation diagnostic'; ...
    'Short-rate transmission wedge'; ...
    'Core-bank short-rate transmission wedge'; ...
    'Ownership mechanism variable; cumulative, overlapping measure'; ...
    'Ownership mechanism variable; cumulative, overlapping measure'; ...
    'Ownership mechanism variable; cumulative, overlapping measure'}, ...
    'VariableNames', {'Variable','Construction','RecommendedUse'});

%% 11. Raw-series metadata sheet
RawMetadata = table( ...
    {'R007';'DR007';'Repo7D';'MLF1Y'}, ...
    {metaR007.Indicator;metaDR007.Indicator;metaRepo7.Indicator;metaMLF.Indicator}, ...
    {metaR007.Frequency;metaDR007.Frequency;metaRepo7.Frequency;metaMLF.Frequency}, ...
    {metaR007.Unit;metaDR007.Unit;metaRepo7.Unit;metaMLF.Unit}, ...
    {metaR007.Source;metaDR007.Source;metaRepo7.Source;metaMLF.Source}, ...
    [min(dateR007);min(dateDR007);min(dateRepo7);min(dateMLF)], ...
    [max(dateR007);max(dateDR007);max(dateRepo7);max(dateMLF)], ...
    [numel(valR007);numel(valDR007);numel(valRepo7);numel(valMLF)], ...
    'VariableNames', {'Series','Indicator','Frequency','Unit','Source', ...
                      'RawStart','RawEnd','RawObservations'});

%% 12. Export
if isfile(outputXlsx)
    delete(outputXlsx);
end

writetable(Master,      outputXlsx, 'Sheet', 'QuarterlyData');
writetable(Definitions, outputXlsx, 'Sheet', 'VariableDefinitions');
writetable(Coverage,    outputXlsx, 'Sheet', 'Coverage');
writetable(RawMetadata, outputXlsx, 'Sheet', 'RawMetadata');

save(outputMat, 'Master', 'Coverage', 'Definitions', 'RawMetadata', ...
    'Repo7_Daily', 'MLF_Monthly');

%% 13. Verification figure
fig = figure('Color','w','Position',[100 100 1150 820]);

subplot(3,1,1);
plot(Master.Date, Master.R007_QMean, 'LineWidth',1.4); hold on;
plot(Master.Date, Master.DR007_QMean, 'LineWidth',1.4);
yline(0,'k-');
grid on; box on;
ylabel('Percent');
title('Quarterly Market Funding Rates');
legend({'R007','DR007'},'Location','best');

subplot(3,1,2);
plot(Master.Date, Master.Repo7D_QMean, 'LineWidth',1.4); hold on;
plot(Master.Date, Master.MLF1Y_QMean, 'LineWidth',1.4);
grid on; box on;
ylabel('Percent');
title('Quarterly PBOC Policy Rates');
legend({'7-day reverse repo','1-year MLF'},'Location','best');

subplot(3,1,3);
plot(Master.Date, Master.FAI_SOE_CumYoY, 'LineWidth',1.2); hold on;
plot(Master.Date, Master.FAI_POE_CumYoY, 'LineWidth',1.2);
plot(Master.Date, Master.FAI_FIE_CumYoY, 'LineWidth',1.2);
grid on; box on;
ylabel('Percent');
xlabel('Quarter');
title('Ownership-Specific Fixed-Asset Investment: YTD Cumulative YoY');
legend({'SOE','Private','Foreign-invested'},'Location','best');

exportgraphics(fig, outputFig, 'Resolution', 300);

fprintf('Saved Excel file: %s\n', outputXlsx);
fprintf('Saved MAT file:   %s\n', outputMat);
fprintf('Saved figure:     %s\n', outputFig);

%% ========================== LOCAL FUNCTIONS ==========================

function [dates, values, meta] = readVendorTwoColumnFile(fileName)
% Read a two-column vendor workbook with metadata in rows 1-9 and data from row 10.

    C = readcell(fileName, 'Sheet', 1);

    meta.Indicator = cellToText(C{2,2});
    meta.Frequency = cellToText(C{4,2});
    meta.Unit      = cellToText(C{5,2});
    meta.Source    = cellToText(C{8,2});

    dateCells = C(10:end,1);
    valCells  = C(10:end,2);

    n = numel(dateCells);
    dates  = NaT(n,1);
    values = nan(n,1);

    for i = 1:n
        dates(i)  = cellToDatetime(dateCells{i});
        values(i) = cellToDouble(valCells{i});
    end

    keep = ~isnat(dates) & isfinite(values);
    dates = dates(keep);
    values = values(keep);

    % Normalize date times to the beginning of the day.
    dates = dateshift(dates, 'start', 'day');

    % Sort and keep the final observation if duplicate dates exist.
    [dates, order] = sort(dates);
    values = values(order);
    [dates, uniqueIdx] = unique(dates, 'last');
    values = values(uniqueIdx);
end

function Q = observedRateToQuarterly(dates, values, startDate, endDate, ...
                                      valueName, countName, minObs)
% Convert actual observed daily rates to quarterly arithmetic means.
% No forward filling is used.

    keep = dates >= startDate & dates <= endDate;
    dates = dates(keep);
    values = values(keep);

    qDate = dateshift(dates, 'end', 'quarter');
    [G, uniqueQ] = findgroups(qDate);

    qMean = splitapply(@(x) mean(x,'omitnan'), values, G);
    qN    = splitapply(@(x) sum(isfinite(x)), values, G);

    qMean(qN < minObs) = NaN;

    Q = table(uniqueQ, qMean, qN, ...
        'VariableNames', {'Date', valueName, countName});
end

function [Q, StepTable] = eventRateToQuarterly( ...
        eventDates, eventValues, startDate, endDate, ...
        valueName, filledCountName, reportedCountName, minFilledObs, frequency)
% Convert an operation/event rate to an effective step-function series.
% frequency = 'daily' or 'monthly'.

    eventDates = dateshift(eventDates, 'start', 'day');
    [eventDates, order] = sort(eventDates);
    eventValues = eventValues(order);
    [eventDates, uniqueIdx] = unique(eventDates, 'last');
    eventValues = eventValues(uniqueIdx);

    % Keep one seed observation at or before the strict start date.
    seed = find(eventDates <= startDate, 1, 'last');
    future = find(eventDates > startDate & eventDates <= endDate);

    if isempty(seed)
        useIdx = future;
    else
        useIdx = [seed; future];
    end

    useDates = eventDates(useIdx);
    useValues = eventValues(useIdx);

    switch lower(frequency)
        case 'daily'
            gridDates = (dateshift(startDate,'start','day'):caldays(1): ...
                         dateshift(endDate,'start','day'))';
            % Calendar-day weighting is appropriate for an effective
            % policy rate that remains in force between operation dates.
            gridValues = interp1(datenum(useDates), useValues, ...
                                 datenum(gridDates), 'previous', NaN);

        case 'monthly'
            useDates = dateshift(useDates, 'end', 'month');
            [useDates, idxM] = unique(useDates, 'last');
            useValues = useValues(idxM);

            firstMonth = dateshift(startDate, 'start', 'month');
            lastMonth  = dateshift(endDate,   'start', 'month');
            gridDates = (firstMonth:calmonths(1):lastMonth)';
            gridDates = dateshift(gridDates, 'end', 'month');

            gridValues = interp1(datenum(useDates), useValues, ...
                                 datenum(gridDates), 'previous', NaN);

        otherwise
            error('Unknown frequency: %s. Use daily or monthly.', frequency);
    end

    StepTable = table(gridDates, gridValues, ...
        'VariableNames', {'Date', valueName});

    qDate = dateshift(gridDates, 'end', 'quarter');
    [G, uniqueQ] = findgroups(qDate);
    qMean = splitapply(@(x) mean(x,'omitnan'), gridValues, G);
    qFilledN = splitapply(@(x) sum(isfinite(x)), gridValues, G);

    % Number of actually reported event/month observations in each quarter.
    reportedDates = eventDates(eventDates >= startDate & eventDates <= endDate);
    reportedQ = dateshift(reportedDates, 'end', 'quarter');
    if isempty(reportedQ)
        reportedCount = zeros(size(uniqueQ));
    else
        [Gr, uniqueQr] = findgroups(reportedQ);
        nReported = splitapply(@numel, reportedDates, Gr);
        reportedTable = table(uniqueQr, nReported, ...
            'VariableNames', {'Date', reportedCountName});
        base = table(uniqueQ, 'VariableNames', {'Date'});
        base = outerjoin(base, reportedTable, 'Keys','Date', ...
            'MergeKeys',true, 'Type','left');
        base.(reportedCountName) = fillmissing(base.(reportedCountName), ...
            'constant', 0);
        reportedCount = base.(reportedCountName);
    end

    qMean(qFilledN < minFilledObs) = NaN;

    Q = table(uniqueQ, qMean, qFilledN, reportedCount, ...
        'VariableNames', {'Date', valueName, filledCountName, reportedCountName});
end

function T = readOwnershipInvestment(fileName, sampleStart, sampleEnd)
% Read the existing quarterly ownership-investment workbook.
% The values are retained as quarter-end YTD cumulative YoY rates.

    raw = readtable(fileName, 'VariableNamingRule','preserve');

    required = {'Date','FAI_State_YoY','FAI_Private_YoY','FAI_Foreign_YoY'};
    for i = 1:numel(required)
        assert(ismember(required{i}, raw.Properties.VariableNames), ...
            'Missing ownership variable in %s: %s', fileName, required{i});
    end

    dates = vectorToDatetime(raw.('Date'));
    dates = dateshift(dates, 'end', 'quarter');

    T = table( ...
        dates, ...
        double(raw.('FAI_State_YoY')), ...
        double(raw.('FAI_Private_YoY')), ...
        double(raw.('FAI_Foreign_YoY')), ...
        'VariableNames', { ...
        'Date','FAI_SOE_CumYoY','FAI_POE_CumYoY','FAI_FIE_CumYoY'});

    T = T(T.Date >= sampleStart & T.Date <= sampleEnd,:);
    T = sortrows(T,'Date');

    [~, ia] = unique(T.Date, 'last');
    T = T(sort(ia),:);
end

function A = leftJoinByDate(A, B)
% Left join B onto the master quarterly calendar using Date.

    A = outerjoin(A, B, 'Keys','Date', ...
        'MergeKeys',true, 'Type','left');
    A = sortrows(A,'Date');
end

function Coverage = buildCoverageTable(T, variableNames)
% Report nonmissing counts and first/last available quarters.

    n = numel(variableNames);
    Variable = strings(n,1);
    NonmissingN = zeros(n,1);
    MissingN = zeros(n,1);
    FirstAvailable = NaT(n,1);
    LastAvailable = NaT(n,1);

    for i = 1:n
        v = variableNames{i};
        assert(ismember(v,T.Properties.VariableNames), ...
            'Coverage variable not found: %s', v);

        x = T.(v);
        ok = isfinite(x);

        Variable(i) = string(v);
        NonmissingN(i) = sum(ok);
        MissingN(i) = sum(~ok);

        if any(ok)
            FirstAvailable(i) = T.Date(find(ok,1,'first'));
            LastAvailable(i)  = T.Date(find(ok,1,'last'));
        end
    end

    Coverage = table(Variable,NonmissingN,MissingN, ...
        FirstAvailable,LastAvailable);
end

function validateRateSeries(dates, values, seriesName)
% Basic validation to catch wrong columns and malformed downloads.

    assert(~isempty(dates), '%s contains no valid observations.', seriesName);
    assert(numel(dates)==numel(values), ...
        '%s date/value lengths differ.', seriesName);
    assert(all(isfinite(values)), '%s contains non-finite values.', seriesName);

    if any(values <= 0) || any(values > 20)
        warning('%s contains values outside the expected 0-20%% range.', seriesName);
    end

    fprintf('%-22s: %s to %s, N = %d, range = %.4f to %.4f\n', ...
        seriesName, datestr(min(dates),'yyyy-mm-dd'), ...
        datestr(max(dates),'yyyy-mm-dd'), numel(values), ...
        min(values), max(values));
end

function d = vectorToDatetime(x)
% Convert a table variable containing datetime, Excel serial dates, strings,
% or cell values to a datetime column.

    if isdatetime(x)
        d = x;
    elseif isnumeric(x)
        d = datetime(x, 'ConvertFrom','excel');
    elseif iscell(x)
        d = NaT(numel(x),1);
        for i = 1:numel(x)
            d(i) = cellToDatetime(x{i});
        end
    else
        d = datetime(x);
    end
end

function d = cellToDatetime(x)
% Convert one spreadsheet cell to datetime.

    d = NaT;
    if isempty(x)
        return;
    end

    if isdatetime(x)
        d = x;
    elseif isnumeric(x) && isscalar(x) && isfinite(x)
        d = datetime(x, 'ConvertFrom','excel');
    elseif ischar(x) || isstring(x)
        s = strtrim(string(x));
        if strlength(s)==0
            return;
        end
        try
            d = datetime(s);
        catch
            d = NaT;
        end
    end
end

function y = cellToDouble(x)
% Convert one spreadsheet cell to a numeric scalar.

    y = NaN;
    if isempty(x)
        return;
    end

    if isnumeric(x) && isscalar(x)
        y = double(x);
    elseif ischar(x) || isstring(x)
        y = str2double(string(x));
    end
end

function s = cellToText(x)
% Convert metadata spreadsheet cell to text.

    if isempty(x)
        s = "";
    elseif isstring(x)
        s = x;
    elseif ischar(x)
        s = string(x);
    elseif isnumeric(x)
        s = string(x);
    else
        s = string(x);
    end
end
