%% =======================================================================
%%  第5节模块: 命题2价格-数量判别(利差条件化) + 命题1/3(iii)所有制缺口
%%  依赖: data0112.xlsx (宏观系统+重构贷款利率i) 与 policy_fai.xlsx (R007+所有制FAI)
%%  前置: 与 rigobon_tlp_pipeline_v2.m 相同的识别管线(此处内嵌精简版)
%%
%%  【真实数据验证运行的三个结论, 代码逻辑据此定型】
%%  1) Prop2判别必须以政策利率为条件: 贷款利率的上行几乎全部来自R007的
%%     内生上行; 利差(i-R007)响应≈0且不显著, TSF显著收缩(t≈-2.3)
%%     → "利差平+量缩" = 需求侧陷阱签名 (供给紧缩要求利差走阔)。
%%  2) 政策反应通道: 高EPU regime中正向信心冲击后R007上行(t≈1.8)
%%     → 这是第2节Remark 1(反转机制)的直接观测, 正文值得单列讨论。
%%  3) 所有制: h=4处 POE -17.5pp(t=-5.7) > SOE -11.8 > FIE -6.1;
%%     POE-SOE缺口在h=8显著(t≈-2.0)。相对预测成立, "SOE完全绝缘"不成立
%%     → 对应引理A.2的部分担保(kappa<1)版本, 5.2节措辞按"约束硬度排序的
%%     差异暴露"来写, 而非"绝缘"。
%% =======================================================================

clear; close all; clc;
rng(1234,'twister');

cfg.p_var = 1;  cfg.p_purge = 2;  cfg.H = 12;  cfg.nboot = 2000;
cfg.gamma_grid = 0.50:0.05:0.85;  cfg.min_obs = 18;

%% ---------- 1. 数据 ----------
d1 = readtable('data0112.xlsx');
d2 = readtable('Processed_PolicyRates_Ownership_Quarterly.xlsx');
assert(height(d1)==height(d2), '两个数据文件行数须一致(2005Q1-2023Q3)');
T  = height(d1);
zs = @(x)(x-mean(x,'omitnan'))./std(x,'omitnan');

lep = log(d1.epu); tt=(1:T)'; bt=[ones(T,1) tt]\lep;
epu = zs(lep-[ones(T,1) tt]*bt);            % 去趋势log-EPU(既定选择)
cci = zs(d1.cnfdc); pmi = zs(d1.pmi); tsf = zs(d1.tsf); gdp = zs(d1.gdp);
Fnd = [zs(d1.iav), zs(d1.cpi), zs(d1.stock)];
lend = d1.i;                                 % 重构贷款利率(pp)
r007 = d2.R007_QMean;                        % 政策利率代理(pp)
sprd = lend - r007;                          % 中介利差 rho —— 判别式对象
soe = d2.FAI_SOE_CumYoY; poe = d2.FAI_POE_CumYoY; fie = d2.FAI_FIE_CumYoY;
D18 = double((1:T)' >= 56);                  % 2018Q4起FAI统计改革断点
Dcovid = double((1:T)'>=61 & (1:T)'<=68);    % 2020Q1-2021Q4基数效应

%% ---------- 2. 净化 + 门限 + 识别 (与v2一致的内嵌精简版) ----------
Ysys = [epu cci pmi tsf gdp];
Xp = [ones(T,1) Fnd];
for j=1:cfg.p_purge, Xp=[Xp lagm(Ysys,j)]; end %#ok<AGROW>
mr = all(isfinite([Xp cci]),2);
s_t = nan(T,1); s_t(mr) = cci(mr) - Xp(mr,:)*(Xp(mr,:)\cci(mr));
Y = [epu s_t pmi tsf gdp]; n=5; kCCI=2;
vn = {'EPU','~s','PMI','TSF','GDP'};

best.c = inf;
for q = cfg.gamma_grid
    I = double(lagm(epu,1) > quantile(epu,q));
    [U,tI] = tvarR(Y,I,cfg.p_var);
    if min(sum(I(tI)==0),sum(I(tI)==1)) < cfg.min_obs, continue; end
    c=0; ok=true;
    for r=0:1
        S=cov(U(I(tI)==r,:)); [~,pc]=chol(S);
        if pc>0, ok=false; break; end
        c=c+sum(I(tI)==r)*log(det(S));
    end
    if ok && c<best.c, best=struct('c',c,'q',q,'I',I); end
end
Ireg=best.I; [U,tI]=tvarR(Y,Ireg,cfg.p_var); Ir=Ireg(tI);
fprintf('门限=EPU %d%%分位 | 低 %d, 高 %d obs\n', round(100*best.q), sum(Ir==0), sum(Ir==1));

[B,ratios] = rigB(cov(U(Ir==0,:)), cov(U(Ir==1,:)));
Eps=(B\U')'; delta=Eps(:,kCCI)/std(Eps(:,kCCI));
fprintf('标签corr=%.3f | 情绪冲击方差比=%.3f\n', corr(delta,U(:,kCCI)), ratios(kCCI));

%% ---------- 3. 命题2: 利差条件化判别 ----------
% 控制集: 系统一阶滞后 + R007滞后(政策利率条件化, 模型判别式的明文要求)
Zbase = [lagm(Y,1), lagm(r007,1)];
P2 = {'贷款利率(pp)',lend; 'R007(pp)',r007; '利差rho(pp)',sprd; 'TSF(std)',tsf};
fprintf('\n===== 命题2判别: 高EPU regime对+1sd信心冲击 =====\n');
fprintf('(供给紧缩→利差走阔; 需求陷阱→利差平/收窄且数量停滞)\n');
res2 = struct();
for k = 1:size(P2,1)
    [bH,bL,sH,~] = tlpNW(P2{k,2}, delta, Ir, Zbase(tI,:), tI, cfg.H);
    res2.(matlab.lang.makeValidName(P2{k,1})) = struct('bH',bH,'bL',bL,'sH',sH);
    fprintf('  %-14s: 累计H4=%7.3f H8=%7.3f | h=4 t=%5.2f | 低EPU H8=%7.3f\n', ...
        P2{k,1}, sum(bH(1:5)), sum(bH(1:9)), bH(5)/sH(5), sum(bL(1:9)));
end

%% ---------- 4. 所有制缺口 + POE-SOE正式检验 ----------
Zown = [Zbase, D18, Dcovid];    % 断点与基数效应虚拟
OWN = {'SOE',soe; 'POE',poe; 'FIE',fie; 'POE_minus_SOE',poe-soe};
fprintf('\n===== 所有制缺口: 逐点响应(pp) =====\n');
irfO = struct();
for k = 1:size(OWN,1)
    [bH,bL,sH,sL] = tlpNW(OWN{k,2}, delta, Ir, Zown(tI,:), tI, cfg.H);
    irfO.(OWN{k,1}) = struct('bH',bH,'bL',bL,'sH',sH,'sL',sL);
    fprintf('  %-14s: h=2 %7.2f(t=%5.2f) h=4 %7.2f(t=%5.2f) h=8 %7.2f(t=%5.2f)\n', ...
        OWN{k,1}, bH(3),bH(3)/sH(3), bH(5),bH(5)/sH(5), bH(9),bH(9)/sH(9));
end
% POE-SOE缺口 = 引理A.2(kappa<1)的正式检验对象: 缺口显著为负 → 硬约束差异暴露成立

%% ---------- 5. Wild bootstrap带 (系统重建, 结果变量用残差wild) ----------
disp('bootstrap...');
Acoef = tvarC(Y,Ireg,cfg.p_var);
keyv = {'利差rho(pp)',sprd; 'TSF(std)',tsf; 'POE',poe; 'SOE',soe; 'POE_minus_SOE',poe-soe};
nb = cfg.nboot; store = nan(nb, size(keyv,1), cfg.H+1, 2);   % [rep,var,h,(H;L)]
for b = 1:nb
    eta = 2*(rand(size(U,1),1)>.5)-1;
    Yb  = rebuild(Y,Acoef,Ireg,U.*eta,cfg.p_var,tI);
    try
        [Ub,tb]=tvarR(Yb,Ireg,cfg.p_var); Irb=Ireg(tb);
        [Bb,~]=rigB(cov(Ub(Irb==0,:)),cov(Ub(Irb==1,:)));
        db=(Bb\Ub')'; db=db(:,kCCI)/std(db(:,kCCI));
        Zb=[lagm(Yb,1), lagm(r007,1)];
        for k=1:size(keyv,1)
            zctl = Zb(tb,:); if k>=3, zctl=[zctl, D18(tb), Dcovid(tb)]; end %#ok<AGROW>
            [bHb,bLb]=tlpNW(keyv{k,2}, db, Irb, zctl, tb, cfg.H);
            store(b,k,:,1)=bHb; store(b,k,:,2)=bLb;
        end
    catch, end
    if mod(b,200)==0, fprintf('  %d/%d\n',b,nb); end
end
fprintf('\n===== 关键量 90%% bootstrap带下的高EPU累计响应(H=8) =====\n');
for k=1:size(keyv,1)
    cums = squeeze(nansum(store(:,k,1:9,1),3));
    ci = quantile(cums(isfinite(cums)),[.05 .95]);
    bH = getIRF(k, keyv, res2, irfO);
    fprintf('  %-14s: %7.3f  [%7.3f, %7.3f]\n', keyv{k,1}, sum(bH(1:9)), ci(1), ci(2));
end

%% ---------- 6. 图: 论文Figure素材 ----------
figure('Position',[60 60 1300 420],'Name','命题2: 价格-数量判别');
sub = {'利差rho(pp)','TSF(std)','R007(pp)'};
for k=1:3
    subplot(1,3,k); hold on
    s = res2.(matlab.lang.makeValidName(sub{k}));
    plot(0:cfg.H, s.bH,'r--','LineWidth',1.8);
    plot(0:cfg.H, s.bL,'b-','LineWidth',1.8);
    yline(0,'k:'); grid on; title(sub{k}); xlabel('季度');
    if k==1, legend({'高EPU','低EPU'}); end
end
sgtitle('对+1sd净化信心冲击的响应: 利差平+数量缩 = 需求侧陷阱');

figure('Position',[60 520 900 420],'Name','所有制缺口');
hold on
plot(0:cfg.H, irfO.POE.bH,'r-','LineWidth',2);
plot(0:cfg.H, irfO.SOE.bH,'k--','LineWidth',2);
plot(0:cfg.H, irfO.FIE.bH,'g-.','LineWidth',1.6);
yline(0,'k:'); grid on; xlabel('季度'); ylabel('FAI累计同比响应(pp)');
legend({'POE(硬约束)','SOE(软约束)','FIE'}); 
title('高EPU regime: 所有制投资响应 — 约束硬度排序的差异暴露');

%% ======================= 局部函数 =======================
function L = lagm(X,j), L=[nan(j,size(X,2)); X(1:end-j,:)]; end

function A = tvarC(Y,I,p)
    T=size(Y,1); X=ones(T,1);
    for j=1:p, X=[X lagm(Y,j)]; end %#ok<AGROW>
    A=cell(2,1);
    for r=0:1
        s=find(all(isfinite([Y X]),2) & I==r); A{r+1}=X(s,:)\Y(s,:);
    end
end

function [U,tI] = tvarR(Y,I,p)
    T=size(Y,1); X=ones(T,1);
    for j=1:p, X=[X lagm(Y,j)]; end %#ok<AGROW>
    tI=find(all(isfinite([Y X]),2)); A=tvarC(Y,I,p);
    U=nan(numel(tI),size(Y,2));
    for k=1:numel(tI), t=tI(k); U(k,:)=Y(t,:)-X(t,:)*A{I(t)+1}; end
end

function [B,ratios] = rigB(SL,SH)
    n=size(SL,1); [V,D]=eig(SH,SL,'vector'); V=real(V); D=real(D);
    B=inv(V');
    if exist('matchpairs','file')
        M=matchpairs(-abs(B),1e6); P=zeros(n);
        for r=1:n, P(M(r,2),M(r,1))=1; end
    else
        P=zeros(n); Ba=abs(B);
        for s=1:n
            [~,l]=max(Ba(:)); [i,j]=ind2sub([n n],l);
            P(j,i)=1; Ba(i,:)=-inf; Ba(:,j)=-inf;
        end
    end
    B=B*P; D=P'*D;
    for j=1:n, B(:,j)=B(:,j)/B(j,j); end
    ratios=D;
end

function Yb = rebuild(Y,A,I,Ub,p,tI)
    Yb=Y;
    for k=1:numel(tI)
        t=tI(k); x=1;
        for j=1:p, x=[x Yb(t-j,:)]; end %#ok<AGROW>
        Yb(t,:)=x*A{I(t)+1}+Ub(k,:);
    end
end

function [bH,bL,sH,sL] = tlpNW(yv,delta,Ir,Z,tI,H)
    Tn=numel(tI); bH=nan(1,H+1); bL=bH; sH=bH; sL=bH;
    for h=0:H
        sel=1:(Tn-h); rows=tI(sel)+h; rows(rows>numel(yv))=numel(yv);
        yy=yv(rows); Ih=Ir(sel); dd=delta(sel); ZZ=Z(sel,:);
        X=[Ih Ih.*dd Ih.*ZZ (1-Ih) (1-Ih).*dd (1-Ih).*ZZ];
        g=all(isfinite([yy X]),2);
        bb=X(g,:)\yy(g); k=2+size(ZZ,2);
        bH(h+1)=bb(2); bL(h+1)=bb(k+2);
        e=yy(g)-X(g,:)*bb; Xe=X(g,:).*e; S=Xe'*Xe;
        for l=1:h+1
            G=Xe(1+l:end,:)'*Xe(1:end-l,:); S=S+(1-l/(h+2))*(G+G');
        end
        XX=pinv(X(g,:)'*X(g,:)); se=sqrt(diag(XX*S*XX));
        sH(h+1)=se(2); sL(h+1)=se(k+2);
    end
end

function bH = getIRF(k, keyv, res2, irfO)
    nm = keyv{k,1};
    if k<=2, bH = res2.(matlab.lang.makeValidName(nm)).bH;
    else,    bH = irfO.(nm).bH; end
end